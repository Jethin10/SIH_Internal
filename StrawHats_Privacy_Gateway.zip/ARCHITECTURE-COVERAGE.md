# Architecture coverage

This file maps the architecture document to the code that exists. It separates the SIH MVP from research and future-product work so the demo claims remain defensible.

## SIH MVP

| Requirement | Status | Evidence |
| --- | --- | --- |
| Manifest V3 extension and generic website coverage | Implemented | `manifest.json` |
| DOM, form, ARIA, open Shadow DOM, and permitted iframe perception | Implemented | `content/content-script.js`, `background/service-worker.js` |
| Incremental privacy graph, mutation tracking, IDs, hashes, versions | Implemented | `content/content-script.js` |
| Immediate pending-mutation flush before context or action use | Implemented | `content/content-script.js` |
| Deterministic PII and Indian identifier rules | Implemented subset suitable for MVP | `lib/pii.js` |
| User vault matching and blind private-value execution | Implemented | `lib/pii.js`, `content/content-script.js` |
| Origin and task-scoped capabilities with field, action, expiry, and use checks | Implemented | `lib/pii.js`, `background/service-worker.js` |
| Task relevance and local disclosure policy | Implemented heuristic | `content/content-script.js` |
| Safe structured context and final egress barrier | Implemented | `content/content-script.js`, `background/service-worker.js` |
| External model planning | Implemented through an HTTPS OpenAI-compatible endpoint | `background/service-worker.js` |
| Strict structured action output | Implemented and unit-tested | `lib/action-policy.js`, `tests/action-policy.test.js` |
| Local target, version, type, token, and risk validation | Implemented | `content/content-script.js` |
| Generic browser execution and feedback loop | Implemented | `background/service-worker.js`, `content/content-script.js` |
| Sensitive-action confirmation | Implemented and tested for block and allow once | `sidepanel`, `tests/cdp-smoke.js` |
| Audit/privacy receipt panel | Implemented | `sidepanel`, `GET_AUDIT` flow |
| Latency and context-size instrumentation | Implemented for scan, mutation, context build, and OCR | `content/content-script.js`, `background/service-worker.js` |
| One local visual fallback demonstration | Implemented and tested with Canvas OCR | `visual`, `tests/integration.html` |

## Implemented defenses beyond the first prototype

- User edits update the graph even when the DOM `value` attribute does not change.
- A context request cannot read through the mutation debounce window.
- Mutation batches over the per-pass cap stay queued instead of disappearing.
- State-changing target actions require a positive `expectedVersion`.
- Planner output rejects unknown properties, unsupported keys, arbitrary scripts, and arbitrary navigation URLs.
- Page-derived aliases cannot be replayed into form fields.
- User/task aliases work only in matching semantic fields and expire after 30 minutes or three uses.
- Private profile data and provider credentials do not persist in `chrome.storage.local`.
- Submit controls receive high-risk treatment from form semantics even when labelled only "Continue".
- Visual OCR text outside opaque regions is not treated as a clickable visual control.
- Visual clicks compare the current viewport pixels with the locally OCR'd screenshot before execution.

## Deliberately not claimed

These architecture sections describe later research or product work, or capabilities Chrome extensions cannot expose cleanly:

| Item | Reason |
| --- | --- |
| WebMCP tool discovery | Emerging site-provided interface; DOM remains the primary path |
| Native browser accessibility tree | Content scripts can read ARIA-derived DOM semantics, not the full privileged AX tree |
| Multilingual ONNX NER and `PENDING` classification queue | Requires a measured model, tokenizer, worker budget, and accuracy benchmark |
| `MASK` and `GENERALIZE` policies | Current MVP uses the safer `TOKENIZE`, `DROP`, and `BLOCK` paths |
| True changed-region OCR and typed visual UI detection | Current fallback uses lazy full-viewport OCR, opaque-region restriction, and pixel freshness checks |
| Delta-only network protocol | The generic chat-completions API is stateless and receives compact snapshots each turn |
| Full remote desktop, Citrix, WebGL game, or scanned-PDF control | The architecture explicitly defers a complete remote-desktop vision system |
| Production credential service, enterprise RBAC, Redis, object storage, and multi-browser support | Explicitly outside the SIH extension MVP |
| Perfect PII recall or perfect OCR | The architecture itself excludes these guarantees |

## Verification commands

```powershell
node tests/pii.test.js
node tests/action-policy.test.js
node tests/run-e2e.js
```

The browser test uses a clean profile. It does not depend on a previously loaded extension or an existing debug browser.
