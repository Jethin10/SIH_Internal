const fs = require("fs");
const http = require("http");
const net = require("net");
const os = require("os");
const path = require("path");
const { spawn } = require("child_process");

const extensionRoot = path.resolve(__dirname, "..");

function freePort() {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once("error", reject);
    server.listen(0, "127.0.0.1", () => {
      const { port } = server.address();
      server.close(() => resolve(port));
    });
  });
}

function chromePath() {
  const candidates = [process.env.CHROME_PATH].filter(Boolean);
  const playwrightRoot = path.join(os.homedir(), "AppData", "Local", "ms-playwright");
  if (fs.existsSync(playwrightRoot)) {
    for (const folder of fs.readdirSync(playwrightRoot).sort().reverse()) {
      candidates.push(path.join(playwrightRoot, folder, "chrome-win64", "chrome.exe"));
    }
  }
  candidates.push(
    path.join(process.env.PROGRAMFILES || "", "Google", "Chrome", "Application", "chrome.exe"),
    path.join(process.env["PROGRAMFILES(X86)"] || "", "Google", "Chrome", "Application", "chrome.exe"),
    path.join(process.env.LOCALAPPDATA || "", "Google", "Chrome", "Application", "chrome.exe")
  );
  const found = candidates.find((candidate) => fs.existsSync(candidate));
  if (!found) throw new Error("Chrome was not found. Set CHROME_PATH to chrome.exe.");
  return found;
}

function staticServer() {
  return http.createServer((request, response) => {
    const urlPath = decodeURIComponent(new URL(request.url, "http://localhost").pathname);
    const relative = urlPath.replace(/^\/+/, "") || "tests/integration.html";
    const target = path.resolve(extensionRoot, relative);
    if (!target.startsWith(extensionRoot + path.sep) || !fs.existsSync(target) || !fs.statSync(target).isFile()) {
      response.writeHead(404).end("Not found");
      return;
    }
    const contentType = target.endsWith(".html") ? "text/html; charset=utf-8" : "application/octet-stream";
    response.writeHead(200, { "Content-Type": contentType, "Cache-Control": "no-store" });
    fs.createReadStream(target).pipe(response);
  });
}

async function waitFor(url, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  let lastError;
  while (Date.now() < deadline) {
    try {
      const response = await fetch(url);
      if (response.ok) return;
    } catch (error) {
      lastError = error;
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error(`Timed out waiting for ${url}: ${lastError?.message || "not ready"}`);
}

async function main() {
  const [webPort, debugPort] = await Promise.all([freePort(), freePort()]);
  const fixtureUrl = `http://127.0.0.1:${webPort}/tests/integration.html`;
  const server = staticServer();
  await new Promise((resolve, reject) => server.once("error", reject).listen(webPort, "127.0.0.1", resolve));
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), "strawhats-e2e-"));
  const browser = spawn(chromePath(), [
    "--headless=new", "--disable-gpu", "--no-first-run", "--no-default-browser-check",
    `--remote-debugging-port=${debugPort}`, "--remote-allow-origins=*", `--user-data-dir=${profile}`,
    `--load-extension=${extensionRoot}`, fixtureUrl
  ], { stdio: "ignore" });
  try {
    await waitFor(`http://127.0.0.1:${debugPort}/json/version`, 15000);
    await waitFor(fixtureUrl, 3000);
    const test = spawn(process.execPath, [path.join(__dirname, "cdp-smoke.js")], {
      cwd: extensionRoot,
      env: { ...process.env, CHROME_DEBUG_PORT: String(debugPort), FIXTURE_URL: fixtureUrl },
      stdio: "inherit"
    });
    const exitCode = await new Promise((resolve) => test.once("exit", resolve));
    if (exitCode !== 0) process.exitCode = exitCode || 1;
  } finally {
    browser.kill();
    await new Promise((resolve) => {
      if (browser.exitCode != null) resolve();
      else browser.once("exit", resolve);
      setTimeout(resolve, 2000);
    });
    server.close();
    if (profile.startsWith(path.join(os.tmpdir(), "strawhats-e2e-"))) {
      try { fs.rmSync(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }); } catch (_) {}
    }
  }
}

main().catch((error) => {
  console.error(error.stack || error);
  process.exitCode = 1;
});
