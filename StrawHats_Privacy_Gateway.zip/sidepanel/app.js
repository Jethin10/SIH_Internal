"use strict";

const $ = (id) => document.getElementById(id);
const state = { settings: null, running: false, lastContext: null, receipts: [] };

function formatBytes(value) {
  const n = Number(value || 0);
  if (n < 1024) return `${Math.round(n)} B`;
  return `${(n / 1024).toFixed(n > 10240 ? 0 : 1)} KB`;
}

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>'"]/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
  })[char]);
}

function setRunning(running) {
  state.running = running;
  $("runButton").disabled = running;
  $("stopButton").classList.toggle("hidden", !running);
  $("stepBadge").textContent = running ? "running" : "idle";
}

function setProviderLine() {
  const provider = state.settings?.provider || {};
  $("providerLine").textContent = provider.apiKey && provider.model
    ? `Cloud reasoning: ${provider.model}`
    : "Local fallback planner. Add a model in Settings for general tasks.";
}

function renderContext(context, localPreview) {
  state.lastContext = context;
  const m = context?.metrics || {};
  $("metricNodes").textContent = Number(m.graphNodes || 0).toLocaleString();
  $("metricSensitive").textContent = Number(m.sensitiveNodes || 0).toLocaleString();
  $("metricChanged").textContent = Number(m.changedNodesLastBatch || 0).toLocaleString();
  $("metricReprocessed").textContent = Number(m.reprocessedLastBatch || 0).toLocaleString();
  $("metricRaw").textContent = formatBytes(m.rawContextBytes);
  $("metricSafe").textContent = formatBytes(m.safeContextBytes);
  $("metricLatency").textContent = `${Number(m.contextBuildMs || 0).toFixed(1)} ms`;
  $("metricRawPii").textContent = Number(m.rawPiiSent || 0).toLocaleString();
  $("pageLabel").textContent = `${context?.page?.origin || ""}${context?.page?.path || ""}` || "Page inspected";

  const preview = localPreview || [];
  $("rawStream").innerHTML = preview.length
    ? preview.slice(0, 10).map((item) => `<div class="stream-item"><code>${escapeHTML(item.local || "[sensitive field]")}</code><small>${escapeHTML(item.type || item.sensitivity)} · local only</small></div>`).join("")
    : '<p class="muted">No sensitive values detected in the current distilled graph.</p>';
  $("safeStream").innerHTML = preview.length
    ? preview.slice(0, 10).map((item) => `<div class="stream-item"><code>${escapeHTML(item.safe || "[blocked]")}</code><small>${escapeHTML(item.policy || "KEEP")}</small></div>`).join("")
    : '<p class="muted">Nothing needed redaction in the current view.</p>';
}

function renderReceipts(receipts) {
  state.receipts = receipts || [];
  $("receiptCount").textContent = String(state.receipts.length);
  $("receipts").innerHTML = state.receipts.length
    ? state.receipts.slice(0, 20).map((item) => `<div class="log-row"><b>${escapeHTML(item.action)}</b> <code>${escapeHTML(item.localDecision)}</code><small>${escapeHTML(item.risk || "low")} risk · ${escapeHTML(new Date(item.at).toLocaleTimeString())}${item.usedPrivateToken ? " · private alias resolved locally" : ""}</small></div>`).join("")
    : '<div class="log-row muted">No local actions recorded yet.</div>';
}

function appendLog(html, className) {
  const log = $("log");
  if (log.children.length === 1 && log.firstElementChild?.classList.contains("muted")) log.innerHTML = "";
  const row = document.createElement("div");
  row.className = `log-row ${className || ""}`;
  row.innerHTML = html;
  log.appendChild(row);
  log.scrollTop = log.scrollHeight;
}

async function request(message) {
  const response = await chrome.runtime.sendMessage(message);
  if (response?.ok === false) throw new Error(response.error || "Request failed");
  return response;
}

async function loadSettings() {
  const response = await request({ type: "GET_SETTINGS" });
  state.settings = response.settings;
  const provider = response.settings.provider || {};
  const profile = response.settings.userProfile || {};
  $("endpointInput").value = provider.endpoint || "";
  $("modelInput").value = provider.model || "";
  $("apiKeyInput").value = provider.apiKey || "";
  $("nameInput").value = profile.name || "";
  $("emailInput").value = profile.email || "";
  $("phoneInput").value = profile.phone || "";
  $("addressInput").value = profile.address || "";
  $("upiInput").value = profile.upi || "";
  setProviderLine();
}

async function saveSettings() {
  const settings = {
    provider: {
      endpoint: $("endpointInput").value.trim(),
      model: $("modelInput").value.trim(),
      apiKey: $("apiKeyInput").value.trim()
    },
    userProfile: {
      name: $("nameInput").value.trim(),
      email: $("emailInput").value.trim(),
      phone: $("phoneInput").value.trim(),
      address: $("addressInput").value.trim(),
      upi: $("upiInput").value.trim()
    }
  };
  await request({ type: "SAVE_SETTINGS", settings });
  state.settings = settings;
  setProviderLine();
  appendLog("<b>Local settings saved.</b> Private profile values remain in extension storage and are exposed to agents as aliases.", "ok");
}

async function refreshContext() {
  try {
    const response = await request({ type: "REFRESH_CONTEXT" });
    if (response.context) renderContext(response.context, response.localPreview);
    renderReceipts(response.receipts);
  } catch (error) {
    appendLog(`<b>Inspect failed.</b> ${escapeHTML(error.message)}`, "blocked");
  }
}

async function visualScan() {
  const button = $("visualButton");
  button.disabled = true;
  button.textContent = "Scanning locally...";
  try {
    const response = await request({ type: "VISUAL_SCAN" });
    if (response.context) renderContext(response.context, response.localPreview);
    appendLog(`<b>Local vision</b> OCR found ${Number(response.visual?.lineCount || 0)} text regions in ${Number(response.visual?.ocrMs || 0).toFixed(0)} ms.`, "ok");
  } catch (error) {
    appendLog(`<b>Visual scan failed.</b> ${escapeHTML(error.message)}`, "blocked");
  } finally {
    button.disabled = false;
    button.textContent = "Local visual scan";
  }
}

async function startTask() {
  const task = $("taskInput").value.trim();
  if (!task) return;
  $("confirmationBox").classList.add("hidden");
  setRunning(true);
  appendLog(`<b>Task</b> ${escapeHTML(task)}`);
  try {
    await request({ type: "START_TASK", task });
  } catch (error) {
    setRunning(false);
    appendLog(`<b>Could not start.</b> ${escapeHTML(error.message)}`, "blocked");
  }
}

async function stopTask() {
  await request({ type: "STOP_TASK" }).catch(() => {});
  setRunning(false);
}

chrome.runtime.onMessage.addListener((message) => {
  if (!message || message.source !== "gateway-worker") return;
  if (message.type === "TASK_STARTED") {
    setRunning(true);
    $("stepBadge").textContent = "step 1";
  } else if (message.type === "CONTEXT") {
    renderContext(message.context, message.localPreview);
  } else if (message.type === "ACTION_PROPOSED") {
    $("stepBadge").textContent = `step ${message.step}`;
    const a = message.action || {};
    appendLog(`<b>Agent proposes</b> <code>${escapeHTML(a.type)}</code>${a.targetId ? ` → <code>${escapeHTML(a.targetId)}</code>` : ""}${a.value ? ` with <code>${escapeHTML(a.value)}</code>` : ""}`);
  } else if (message.type === "ACTION_RESULT") {
    const r = message.result || {};
    const cls = r.status === "blocked" ? "blocked" : "ok";
    appendLog(`<b>Local firewall</b> ${escapeHTML(r.status || "unknown")}${r.reason ? ` · ${escapeHTML(r.reason)}` : ""}`, cls);
    if (r.receipt) renderReceipts([r.receipt, ...state.receipts.filter((item) => item.at !== r.receipt.at)]);
  } else if (message.type === "VISUAL_OCR_PROGRESS") {
    const pct = Math.round(Number(message.progress || 0) * 100);
    $("stepBadge").textContent = `vision ${pct}%`;
  } else if (message.type === "VISUAL_CONTEXT") {
    appendLog(`<b>Local vision ready.</b> ${Number(message.lineCount || 0)} safe OCR regions · ${Number(message.ocrMs || 0).toFixed(0)} ms.`);
  } else if (message.type === "CONFIRMATION_REQUIRED") {
    const action = message.action || {};
    $("confirmationBox").classList.remove("hidden");
    $("confirmationTitle").textContent = action.reason || "Local confirmation required";
    $("confirmationReason").textContent = message.result?.reason || "This action can create an external side effect.";
    $("confirmationAction").textContent = JSON.stringify(action, null, 2);
    $("confirmationBox").scrollIntoView({ behavior: "smooth", block: "center" });
  } else if (message.type === "TASK_DONE") {
    setRunning(false);
    $("confirmationBox").classList.add("hidden");
    appendLog(`<b>Done.</b> ${escapeHTML(message.message || "Task complete")}`, "ok");
  } else if (message.type === "TASK_ERROR") {
    setRunning(false);
    $("confirmationBox").classList.add("hidden");
    appendLog(`<b>Agent error.</b> ${escapeHTML(message.error || "Unknown error")}`, "blocked");
  }
});

$("runButton").addEventListener("click", startTask);
$("refreshButton").addEventListener("click", refreshContext);
$("visualButton").addEventListener("click", visualScan);
$("stopButton").addEventListener("click", stopTask);
$("saveSettingsButton").addEventListener("click", saveSettings);
$("allowButton").addEventListener("click", async () => {
  $("confirmationBox").classList.add("hidden");
  try { await request({ type: "CONFIRM_PENDING", allow: true }); }
  catch (error) { appendLog(`<b>Confirmation failed.</b> ${escapeHTML(error.message)}`, "blocked"); }
});
$("blockButton").addEventListener("click", async () => {
  $("confirmationBox").classList.add("hidden");
  try { await request({ type: "CONFIRM_PENDING", allow: false }); }
  catch (error) { appendLog(`<b>Block failed.</b> ${escapeHTML(error.message)}`, "blocked"); }
});
$("taskInput").addEventListener("keydown", (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key === "Enter") startTask();
});

loadSettings().then(refreshContext).catch((error) => appendLog(`<b>Startup.</b> ${escapeHTML(error.message)}`, "blocked"));
