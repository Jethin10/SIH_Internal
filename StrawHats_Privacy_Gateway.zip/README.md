# StrawHats Privacy Gateway

Chrome Manifest V3 prototype for SIH 26171. It is a generic browser privacy layer, not a site-specific Aadhaar demo.

## What is implemented

- Generic DOM, form, ARIA, open Shadow DOM, dynamic-page, and permitted iframe perception on HTTP and HTTPS pages.
- An in-memory incremental privacy graph with semantic element IDs, content hashes, versions, mutation batching, and immediate flushes at egress and execution boundaries.
- Capturing `input` and `change` listeners so user-entered values cannot bypass graph updates.
- Local deterministic detection for email, Indian phone, PAN, checksum-valid Aadhaar, UPI, payment cards, IFSC, passport, voter ID, JWT, IPv4, password/secret fields, and user-profile values.
- Task relevance and `KEEP`, `TOKENIZE`, `DROP`, and `BLOCK` disclosure decisions.
- Task-scoped private aliases with origin isolation, destination-field checks, expiry, action constraints, and use limits.
- A final outbound check that blocks known raw private values or recognizer-detectable PII before a provider request.
- A strict action schema. Arbitrary JavaScript, arbitrary URLs, unknown fields, missing versions, and unsupported keys are rejected.
- Generic click, fill, select, press, focus, scroll, wait, history-back, and link-navigation behavior.
- A local firewall with target and version revalidation, disabled/type checks, form-semantic risk checks, and allow-once confirmation for high-risk actions.
- Local action receipts shown in the side panel.
- Fully local Tesseract OCR for opaque Canvas, WebGL, video, embedded document, and similar visible regions.
- Visual actions restricted to OCR text inside known opaque regions, with page-epoch and exact visible-pixel freshness checks before execution and again after confirmation.
- Session-only storage for provider API keys and the private profile. Persistent extension storage contains only the alias seed, endpoint, model name, and non-sensitive preferences.

## Install

1. Open `chrome://extensions`.
2. Enable Developer mode.
3. Click **Load unpacked**.
4. Select this `extension` directory.
5. Reload pages that were already open.
6. Click the extension action to open the side panel.

The local fallback planner handles direct click, search, scrolling, history-back, and saved-profile fill commands. Add an HTTPS OpenAI-compatible chat-completions endpoint and model in Settings for general planning. The API key and private profile last only for the current browser session.

## Verify

Run the complete suite from this directory:

```powershell
node tests/pii.test.js
node tests/action-policy.test.js
node tests/run-e2e.js
```

`run-e2e.js` starts a clean temporary Chromium profile, loads the unpacked extension, serves the fixture, exercises the real content script and service worker, then closes the browser. Set `CHROME_PATH` only if it cannot find Chrome or Playwright Chromium.

The end-to-end test covers local secret storage, structured extraction, PII redaction, private-capability filling, user-input freshness, local OCR, browser actions, incremental mutations, high-risk block and allow-once paths, form-semantic risk detection, and audit receipt retrieval.

## Honest boundaries

Chrome blocks ordinary extension access to browser-internal pages, closed shadow roots, some sandboxed frames, browser-owned PDF viewers, and privileged surfaces. The extension fails without context on those pages instead of sending raw pixels to a cloud model.

The architecture document deliberately places WebMCP, a multilingual local NER model, browser-level accessibility-tree access, typed visual control detection, changed-region OCR, stateless-provider delta transport, remote-desktop support, and enterprise administration beyond the SIH MVP. Those items remain future work and are listed precisely in [ARCHITECTURE-COVERAGE.md](ARCHITECTURE-COVERAGE.md).

No PII detector or OCR engine has perfect recall. The code now enforces the mechanisms the prototype can honestly prove, but it should not be represented as a production security boundary against a compromised browser or operating system.
