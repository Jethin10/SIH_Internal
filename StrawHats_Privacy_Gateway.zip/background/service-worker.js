"use strict";

importScripts("../lib/pii.js");
importScripts("../lib/action-policy.js");
const PII = globalThis.PrivacyPII;
const ActionPolicy = globalThis.PrivacyActionPolicy;

const sessions = new Map();
const visualCache = new Map();
const DEFAULT_SETTINGS = {
  aliasSeed: "",
  provider: {
    endpoint: "https://openrouter.ai/api/v1/chat/completions",
    apiKey: "",
    model: ""
  },
  userProfile: {
    name: "",
    email: "",
    phone: "",
    address: "",
    upi: ""
  }
};

chrome.runtime.onInstalled.addListener(async () => {
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  const stored = await chrome.storage.local.get(["gatewaySettings"]);
  if (!stored.gatewaySettings) {
    await chrome.storage.local.set({ gatewaySettings: publicSettings({ ...DEFAULT_SETTINGS, aliasSeed: crypto.randomUUID() }) });
  }
});

chrome.runtime.onStartup.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});

function broadcast(message) {
  chrome.runtime.sendMessage({ source: "gateway-worker", ...message }).catch(() => {});
}

async function getSettings() {
  const [stored, secretStore] = await Promise.all([
    chrome.storage.local.get(["gatewaySettings"]),
    chrome.storage.session.get(["gatewaySecrets"])
  ]);
  const persisted = mergeSettings(stored.gatewaySettings || DEFAULT_SETTINGS);
  const legacySecrets = { apiKey: persisted.provider.apiKey || "", userProfile: persisted.userProfile || {} };
  const secrets = secretStore.gatewaySecrets || legacySecrets;
  const settings = mergeSettings({
    ...persisted,
    provider: { ...persisted.provider, apiKey: secrets.apiKey || "" },
    userProfile: { ...DEFAULT_SETTINGS.userProfile, ...(secrets.userProfile || {}) }
  });
  if (!settings.aliasSeed) {
    settings.aliasSeed = crypto.randomUUID();
  }
  if (!secretStore.gatewaySecrets && (legacySecrets.apiKey || Object.values(legacySecrets.userProfile).some(Boolean))) {
    await chrome.storage.session.set({ gatewaySecrets: legacySecrets });
  }
  await chrome.storage.local.set({ gatewaySettings: publicSettings(settings) });
  return settings;
}

function mergeSettings(next) {
  return {
    aliasSeed: next?.aliasSeed || "",
    provider: { ...DEFAULT_SETTINGS.provider, ...(next?.provider || {}) },
    userProfile: { ...DEFAULT_SETTINGS.userProfile, ...(next?.userProfile || {}) }
  };
}

function publicSettings(settings) {
  const merged = mergeSettings(settings);
  return {
    aliasSeed: merged.aliasSeed,
    provider: { endpoint: merged.provider.endpoint, model: merged.provider.model, apiKey: "" },
    userProfile: { ...DEFAULT_SETTINGS.userProfile }
  };
}

async function saveSettings(settings) {
  const merged = mergeSettings(settings);
  await Promise.all([
    chrome.storage.local.set({ gatewaySettings: publicSettings(merged) }),
    chrome.storage.session.set({ gatewaySecrets: { apiKey: merged.provider.apiKey, userProfile: { ...merged.userProfile } } })
  ]);
  return merged;
}

async function activeTabId() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];
  if (!tab?.id) throw new Error("No active browser tab");
  if (!/^https?:/i.test(tab.url || "")) throw new Error("Open a normal http/https webpage first");
  return tab.id;
}

async function framesForTab(tabId) {
  try {
    const frames = await chrome.webNavigation.getAllFrames({ tabId });
    return frames?.length ? frames : [{ frameId: 0 }];
  } catch (_) {
    return [{ frameId: 0 }];
  }
}

async function sendFrame(tabId, frameId, message) {
  return chrome.tabs.sendMessage(tabId, message, { frameId });
}

async function sendAllFrames(tabId, message) {
  const frames = await framesForTab(tabId);
  const results = await Promise.allSettled(frames.map((frame) => sendFrame(tabId, frame.frameId, message)));
  return results.map((result, index) => ({ frameId: frames[index].frameId, result })).filter((item) => item.result.status === "fulfilled");
}

async function syncSettings(tabId) {
  const settings = await getSettings();
  await sendAllFrames(tabId, { type: "SYNC_SETTINGS", settings });
}

async function prepareTaskPrivacy(tabId, task, settings, taskScope) {
  const tab = await chrome.tabs.get(tabId);
  const origin = new URL(tab.url).origin;
  const taskVault = new PII.AliasVault(`${settings.aliasSeed}|${origin}|${taskScope}`);
  taskVault.registerUserProfile(settings.userProfile || {});
  const redacted = PII.redactText(task, taskVault);
  const entities = (redacted.entities || []).map((entity) => ({
    type: entity.type,
    value: entity.value,
    token: entity.token
  }));
  if (entities.length) await sendAllFrames(tabId, { type: "REGISTER_TASK_VALUES", entities });
  return { safeTask: redacted.safe, entities };
}

async function ensureOffscreenDocument() {
  const url = chrome.runtime.getURL("visual/offscreen.html");
  if (chrome.runtime.getContexts) {
    const existing = await chrome.runtime.getContexts({
      contextTypes: ["OFFSCREEN_DOCUMENT"],
      documentUrls: [url]
    });
    if (existing.length) return;
  }
  try {
    await chrome.offscreen.createDocument({
      url: "visual/offscreen.html",
      reasons: [chrome.offscreen.Reason.BLOBS],
      justification: "Run local OCR and image processing without sending screenshots off-device"
    });
  } catch (error) {
    if (!/single offscreen|already exists/i.test(error?.message || "")) throw error;
  }
}

function parseOCRLines(tsv, imageWidth, imageHeight, safeContext, settings) {
  const viewport = safeContext.page?.viewport || { width: imageWidth, height: imageHeight };
  const scaleX = Number(viewport.width || imageWidth) / Math.max(1, Number(imageWidth || 1));
  const scaleY = Number(viewport.height || imageHeight) / Math.max(1, Number(imageHeight || 1));
  const vault = new PII.AliasVault(`${settings.aliasSeed}|${safeContext.page.origin}`);
  vault.registerUserProfile(settings.userProfile || {});
  const lines = new Map();
  const rows = String(tsv || "").split(/\r?\n/);

  for (let i = 1; i < rows.length; i += 1) {
    if (!rows[i].trim()) continue;
    const cols = rows[i].split("\t");
    if (cols.length < 12 || Number(cols[0]) !== 5) continue;
    const confidence = Number(cols[10]);
    const text = cols.slice(11).join("\t").trim();
    if (!text || confidence < 20) continue;
    const key = `${cols[2]}:${cols[3]}:${cols[4]}`;
    const left = Number(cols[6]);
    const top = Number(cols[7]);
    const width = Number(cols[8]);
    const height = Number(cols[9]);
    const right = left + width;
    const bottom = top + height;
    const line = lines.get(key) || { words: [], left, top, right, bottom, confidenceTotal: 0, confidenceCount: 0 };
    line.words.push(text);
    line.left = Math.min(line.left, left);
    line.top = Math.min(line.top, top);
    line.right = Math.max(line.right, right);
    line.bottom = Math.max(line.bottom, bottom);
    line.confidenceTotal += confidence;
    line.confidenceCount += 1;
    lines.set(key, line);
  }

  const elements = [];
  const localPreview = [];
  for (const [key, line] of lines.entries()) {
    const rawText = line.words.join(" ").replace(/\s+/g, " ").trim();
    if (rawText.length < 2) continue;
    const redacted = PII.redactText(rawText, vault);
    const bbox = {
      x: Math.round(line.left * scaleX),
      y: Math.round(line.top * scaleY),
      width: Math.max(1, Math.round((line.right - line.left) * scaleX)),
      height: Math.max(1, Math.round((line.bottom - line.top) * scaleY))
    };
    const centerX = bbox.x + bbox.width / 2;
    const centerY = bbox.y + bbox.height / 2;
    const insideOpaqueRegion = (safeContext.opaqueRegions || []).some((region) => {
      const box = region.bbox || {};
      return centerX >= box.x && centerX <= box.x + box.width && centerY >= box.y && centerY <= box.y + box.height;
    });
    const id = `v_${PII.hashText(`${safeContext.page.epoch}|${key}|${redacted.safe}|${bbox.x}|${bbox.y}`)}`;
    elements.push({
      id,
      frameId: 0,
      source: "vision",
      role: "visual_text",
      label: redacted.safe,
      value: "",
      semanticType: "visual",
      actionable: insideOpaqueRegion,
      sensitivity: redacted.sensitivity,
      policy: redacted.sensitivity === "none" ? "KEEP" : "TOKENIZE",
      relevance: 0.5,
      version: 1,
      disabled: false,
      confidence: Number((line.confidenceTotal / Math.max(1, line.confidenceCount)).toFixed(1)),
      bbox
    });
    for (const entity of redacted.entities || []) {
      localPreview.push({
        id,
        local: entity.value,
        safe: entity.token,
        policy: "TOKENIZE",
        type: entity.type.toLowerCase(),
        sensitivity: ["CARD", "AADHAAR", "SECRET", "JWT"].includes(entity.type) ? "critical" : "personal",
        source: "vision"
      });
    }
  }
  return { elements: elements.slice(0, 180), localPreview: localPreview.slice(0, 20) };
}

async function captureVisualContext(tabId, safeContext) {
  const settings = await getSettings();
  const tab = await chrome.tabs.get(tabId);
  if (!tab.windowId) throw new Error("Cannot capture the current browser window");
  await ensureOffscreenDocument();
  broadcast({ type: "VISUAL_OCR_PROGRESS", status: "capturing visible page locally", progress: 0 });
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
  const screenshotHash = await hashDataUrl(dataUrl);
  const cached = visualCache.get(tabId);
  if (cached && cached.screenshotHash === screenshotHash && Number(cached.epoch) === Number(safeContext.page?.epoch || 0)) return cached;
  const result = await chrome.runtime.sendMessage({ target: "offscreen", type: "OCR_IMAGE", dataUrl });
  if (!result?.ok) throw new Error(result?.error || "Local OCR failed");
  const parsed = parseOCRLines(result.tsv, result.imageWidth, result.imageHeight, safeContext, settings);
  const visual = {
    epoch: Number(safeContext.page?.epoch || 0),
    elements: parsed.elements,
    localPreview: parsed.localPreview,
    ocrMs: Number(result.ocrMs || 0),
    confidence: Number(result.confidence || 0),
    imageWidth: Number(result.imageWidth || 0),
    imageHeight: Number(result.imageHeight || 0),
    screenshotHash
  };
  visualCache.set(tabId, visual);
  broadcast({
    type: "VISUAL_CONTEXT",
    tabId,
    lineCount: visual.elements.length,
    ocrMs: visual.ocrMs,
    confidence: visual.confidence
  });
  return visual;
}

async function hashDataUrl(dataUrl) {
  const bytes = new TextEncoder().encode(String(dataUrl || ""));
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest)).map((value) => value.toString(16).padStart(2, "0")).join("");
}

async function visualObservationIsCurrent(tabId, visual) {
  if (!visual?.screenshotHash) return false;
  const tab = await chrome.tabs.get(tabId);
  if (!tab.windowId) return false;
  const current = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
  return (await hashDataUrl(current)) === visual.screenshotHash;
}

function augmentWithVisual(safeContext, visual) {
  if (!visual || Number(visual.epoch) !== Number(safeContext.page?.epoch)) return safeContext;
  return {
    ...safeContext,
    elements: [...safeContext.elements, ...visual.elements].slice(0, 380),
    visual: {
      scanned: true,
      lineCount: visual.elements.length,
      ocrMs: visual.ocrMs,
      confidence: visual.confidence,
      epoch: visual.epoch
    },
    metrics: {
      ...safeContext.metrics,
      visualOcrMs: visual.ocrMs,
      visualLines: visual.elements.length
    }
  };
}

function shouldAutoVisualScan(safeContext) {
  if (Number(safeContext.metrics?.actionableNodes || 0) >= 3) return false;
  return (safeContext.opaqueRegions || []).some((region) => Number(region.viewportShare || 0) >= 0.25);
}

async function collectContext(tabId) {
  const frames = await framesForTab(tabId);
  const pieces = [];
  for (const frame of frames) {
    try {
      const response = await sendFrame(tabId, frame.frameId, { type: "GET_SAFE_CONTEXT" });
      if (response?.context) pieces.push({ frameId: frame.frameId, ...response });
    } catch (_) {}
  }
  if (!pieces.length) throw new Error("Privacy Gateway is not available on this page. Reload the tab after loading the extension.");

  const elements = [];
  const localPreview = [];
  const opaqueRegions = [];
  const vaultCapabilities = new Map();
  const metrics = {
    graphNodes: 0,
    actionableNodes: 0,
    sensitiveNodes: 0,
    changedNodesLastBatch: 0,
    reprocessedLastBatch: 0,
    rawContextBytes: 0,
    safeContextBytes: 0,
    contextBuildMs: 0,
    framesObserved: pieces.length,
    rawPiiSent: 0
  };
  let page = null;

  for (const piece of pieces) {
    if (piece.frameId === 0) {
      page = piece.context.page;
      for (const region of piece.context.opaqueRegions || []) opaqueRegions.push({ ...region, frameId: 0 });
    }
    for (const element of piece.context.elements || []) {
      elements.push({ ...element, frameId: piece.frameId });
    }
    for (const capability of piece.context.vaultCapabilities || []) vaultCapabilities.set(capability.token, capability);
    for (const preview of piece.localPreview || []) localPreview.push({ ...preview, frameId: piece.frameId });
    const m = piece.context.metrics || {};
    metrics.graphNodes += Number(m.graphNodes || 0);
    metrics.actionableNodes += Number(m.actionableNodes || 0);
    metrics.sensitiveNodes += Number(m.sensitiveNodes || 0);
    metrics.changedNodesLastBatch += Number(m.changedNodesLastBatch || 0);
    metrics.reprocessedLastBatch += Number(m.reprocessedLastBatch || 0);
    metrics.rawContextBytes += Number(m.rawContextBytes || 0);
    metrics.safeContextBytes += Number(m.safeContextBytes || 0);
    metrics.contextBuildMs += Number(m.lastContextBuildMs || 0);
  }

  elements.sort((a, b) => Number(b.actionable) - Number(a.actionable) || Number(b.relevance || 0) - Number(a.relevance || 0));
  const safeContext = {
    page: page || pieces[0].context.page,
    elements: elements.slice(0, 260),
    opaqueRegions,
    vaultCapabilities: Array.from(vaultCapabilities.values()),
    metrics
  };
  return { safeContext, localPreview: localPreview.slice(0, 20), elementFrames: new Map(elements.map((element) => [element.id, element.frameId])) };
}

async function collectAudit(tabId) {
  const frames = await framesForTab(tabId);
  const receipts = [];
  for (const frame of frames) {
    try {
      const state = await sendFrame(tabId, frame.frameId, { type: "GET_DEBUG_STATE" });
      for (const item of state?.receipts || []) receipts.push({ ...item, frameId: frame.frameId });
    } catch (_) {}
  }
  receipts.sort((a, b) => String(b.at).localeCompare(String(a.at)));
  return receipts.slice(0, 50);
}

function compactForPlanner(safeContext) {
  return {
    page: safeContext.page,
    visual: safeContext.visual || null,
    opaqueRegions: safeContext.opaqueRegions || [],
    vaultCapabilities: safeContext.vaultCapabilities,
    elements: safeContext.elements.map((element) => ({
      id: element.id,
      frameId: element.frameId,
      source: element.source || "structure",
      role: element.role,
      label: element.label,
      value: element.value,
      semanticType: element.semanticType,
      actionable: element.actionable,
      sensitivity: element.sensitivity,
      policy: element.policy,
      version: element.version,
      checked: element.checked,
      disabled: element.disabled,
      bbox: element.source === "vision" ? element.bbox : undefined
    }))
  };
}

function assertEgressSafe(safeContext, localPreview, settings) {
  const payload = compactForPlanner(safeContext);
  const serialized = JSON.stringify(payload).toLocaleLowerCase();
  const privateValues = [
    ...(localPreview || []).map((item) => item.local),
    ...Object.values(settings.userProfile || {})
  ].map((value) => String(value || "").trim()).filter((value) => value.length >= 3);
  for (const value of privateValues) {
    if (serialized.includes(value.toLocaleLowerCase())) throw new Error("Egress barrier blocked a raw private value");
  }
  for (const element of payload.elements || []) {
    const visibleText = `${element.label || ""} ${element.value || ""}`;
    if (PII.findPII(visibleText).length) throw new Error("Egress barrier found unclassified PII in safe context");
  }
  return payload;
}

function extractJSON(text) {
  const raw = String(text || "").trim();
  if (!raw) throw new Error("Agent returned an empty response");
  try { return JSON.parse(raw); } catch (_) {}
  const fenced = raw.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced) return JSON.parse(fenced[1]);
  const start = raw.indexOf("{");
  const end = raw.lastIndexOf("}");
  if (start >= 0 && end > start) return JSON.parse(raw.slice(start, end + 1));
  throw new Error("Agent response was not valid JSON");
}

async function remotePlan(task, safeContext, history, settings, localPreview) {
  const endpoint = settings.provider.endpoint.trim();
  const apiKey = settings.provider.apiKey.trim();
  const model = settings.provider.model.trim();
  if (!endpoint || !apiKey || !model) return null;
  const endpointUrl = new URL(endpoint);
  if (endpointUrl.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(endpointUrl.hostname)) {
    throw new Error("Reasoning endpoint must use HTTPS");
  }

  const systemPrompt = `You are a browser action planner behind a privacy gateway. You NEVER receive raw private values.\n\nReturn exactly one JSON object and nothing else. Valid actions:\n{"type":"click","targetId":"...","expectedVersion":1,"reason":"..."}\n{"type":"fill","targetId":"...","value":"literal or <PRIVATE:TOKEN>","expectedVersion":1,"reason":"..."}\n{"type":"select","targetId":"...","value":"visible option or value","expectedVersion":1,"reason":"..."}\n{"type":"press","targetId":"...","key":"Enter","expectedVersion":1,"reason":"..."}\n{"type":"focus","targetId":"...","expectedVersion":1,"reason":"..."}\n{"type":"scroll","direction":"down|up","amount":600,"reason":"..."}\n{"type":"wait","ms":350,"reason":"..."}\n{"type":"back","reason":"Return to the previous history entry"}\n{"type":"visual_scan","reason":"Structured context is insufficient"}\n{"type":"done","message":"answer or completion message"}\n\nRules:\n- Only use targetId values present in the supplied context.\n- Copy the element version into expectedVersion for structured targets.\n- Elements with source=vision came from local OCR. They support click/press only; their screenshot geometry is revalidated locally before execution.\n- If an opaque Canvas/WebGL/PDF-like region matters but visual.scanned is false and structured context is insufficient, request visual_scan.\n- Private user values are represented by vault capability tokens. Use those tokens directly; never ask for the raw value.\n- Prefer structured element labels and roles before vision.\n- Never invent a URL or execute JavaScript.\n- For read-only questions, inspect the supplied safe text and return done with the answer when sufficient.\n- If the previous action was blocked, choose a safe alternative or return done explaining why.\n- One action per turn.`;

  const body = {
    model,
    temperature: 0,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: JSON.stringify({ task, context: assertEgressSafe(safeContext, localPreview, settings), history: history.slice(-6) }) }
    ]
  };

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify(body)
  });
  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Agent API ${response.status}: ${text.slice(0, 220)}`);
  }
  const data = await response.json();
  const content = data?.choices?.[0]?.message?.content ?? data?.output_text ?? data?.content;
  return extractJSON(content);
}

function bestElement(elements, predicate) {
  return elements.find((element) => element.actionable && !element.disabled && predicate(element));
}

function localPlan(task, safeContext, history) {
  const lower = task.toLowerCase().trim();
  const elements = safeContext.elements;
  const last = history[history.length - 1];

  if (last?.action?.reason === "Local fallback" && last?.result?.status === "executed") {
    return { type: "done", message: "Local fallback action completed." };
  }
  if (["Matched requested control", "Submit search", "Use local email capability", "Use local phone capability", "Use local name capability", "Use local address capability", "Use local upi capability"].includes(last?.action?.reason) && last?.result?.status === "executed") {
    return { type: "done", message: "Local fallback task completed." };
  }

  if (/^scroll\s+up/.test(lower)) return { type: "scroll", direction: "up", amount: 650, reason: "Local fallback" };
  if (/^scroll|scroll\s+down/.test(lower)) return { type: "scroll", direction: "down", amount: 650, reason: "Local fallback" };
  if (/^(?:go\s+)?back$/.test(lower)) return { type: "back", reason: "User requested browser history navigation" };

  const clickMatch = task.match(/(?:click|press|open)\s+(?:on\s+)?["']?(.+?)["']?$/i);
  if (clickMatch) {
    const needle = clickMatch[1].trim().toLowerCase();
    const target = bestElement(elements, (element) => `${element.label} ${element.value}`.toLowerCase().includes(needle));
    if (target) return { type: "click", targetId: target.id, expectedVersion: target.version, reason: "Matched requested control" };
    if (!safeContext.visual?.scanned) return { type: "visual_scan", reason: "Requested control was not present in structured context" };
  }

  const searchMatch = task.match(/search(?:\s+for)?\s+["']?(.+?)["']?$/i);
  if (searchMatch) {
    const query = searchMatch[1].trim();
    const search = bestElement(elements, (element) => element.semanticType === "search" || /search/.test(`${element.label}`.toLowerCase()));
    if (search) {
      if (String(search.value || "").toLowerCase().includes(query.toLowerCase()) || last?.action?.type === "fill") {
        const button = bestElement(elements, (element) => element.role === "button" && /search|go/.test(element.label.toLowerCase()));
        if (button) return { type: "click", targetId: button.id, expectedVersion: button.version, reason: "Submit search" };
        return { type: "press", targetId: search.id, expectedVersion: search.version, key: "Enter", reason: "Submit search" };
      }
      return { type: "fill", targetId: search.id, expectedVersion: search.version, value: query, reason: "Fill search box" };
    }
    if (!safeContext.visual?.scanned && (safeContext.opaqueRegions || []).length) {
      return { type: "visual_scan", reason: "Search control may be inside an opaque visual region" };
    }
  }

  const requestedTypes = [
    ["email", "EMAIL"], ["phone", "PHONE"], ["mobile", "PHONE"], ["name", "PERSON"],
    ["address", "ADDRESS"], ["upi", "UPI"]
  ];
  if (/fill|enter|type|use my/.test(lower)) {
    for (const [word, capabilityType] of requestedTypes) {
      if (!lower.includes(word)) continue;
      const capability = safeContext.vaultCapabilities.find((item) => item.type === capabilityType);
      const target = bestElement(elements, (element) => element.role === "textbox" && (element.semanticType === word || element.label.toLowerCase().includes(word)));
      if (capability && target) return { type: "fill", targetId: target.id, expectedVersion: target.version, value: capability.token, reason: `Use local ${word} capability` };
    }
  }

  return {
    type: "done",
    message: "The local fallback planner only handles direct click, scroll, search, and saved-profile fill commands. Configure an OpenAI-compatible model in Settings for general web tasks."
  };
}

async function planAction(session, safeContext, localPreview) {
  const settings = await getSettings();
  const hasRemote = Boolean(settings.provider.endpoint.trim() && settings.provider.apiKey.trim() && settings.provider.model.trim());
  if (hasRemote) return remotePlan(session.safeTask, safeContext, session.history, settings, localPreview);
  return localPlan(session.task, safeContext, session.history);
}

function frameForAction(action, elementFrames) {
  if (!action?.targetId) return 0;
  return elementFrames.get(action.targetId) ?? 0;
}

async function runSession(tabId) {
  const session = sessions.get(tabId);
  if (!session || session.running) return;
  session.running = true;
  try {
    for (; session.step < 10 && !session.cancelled; session.step += 1) {
      const collected = await collectContext(tabId);
      session.elementFrames = collected.elementFrames;
      let visual = visualCache.get(tabId) || null;
      if (visual && Number(visual.epoch) !== Number(collected.safeContext.page?.epoch)) {
        visualCache.delete(tabId);
        visual = null;
      }
      if (!visual && shouldAutoVisualScan(collected.safeContext)) {
        visual = await captureVisualContext(tabId, collected.safeContext);
      }
      const safeContext = augmentWithVisual(collected.safeContext, visual);
      const localPreview = visual
        ? [...collected.localPreview, ...(visual.localPreview || [])].slice(0, 24)
        : collected.localPreview;
      broadcast({ type: "CONTEXT", tabId, context: safeContext, localPreview });
      const action = await planAction(session, safeContext, localPreview);
      const schema = ActionPolicy.validate(action);
      if (!schema.ok) throw new Error(`Planner returned an invalid action: ${schema.reason}`);
      broadcast({ type: "ACTION_PROPOSED", tabId, action, step: session.step + 1 });

      if (action.type === "visual_scan") {
        const captured = await captureVisualContext(tabId, collected.safeContext);
        session.history.push({
          action,
          result: { status: "executed", localOnly: true, visualLines: captured.elements.length, ocrMs: captured.ocrMs }
        });
        continue;
      }

      if (action.type === "done") {
        session.history.push({ action, result: { status: "done" } });
        broadcast({ type: "TASK_DONE", tabId, message: action.message || "Task complete", history: session.history });
        sessions.delete(tabId);
        return;
      }

      if (action.type === "back") {
        await chrome.tabs.goBack(tabId);
        const result = { status: "executed", risk: "low", action: "back" };
        session.history.push({ action, result });
        broadcast({ type: "ACTION_RESULT", tabId, action, result });
        await new Promise((resolve) => setTimeout(resolve, 500));
        continue;
      }

      const visualTarget = safeContext.elements.find((element) => element.source === "vision" && element.id === action.targetId) || null;
      const frameId = visualTarget ? 0 : frameForAction(action, collected.elementFrames);
      const executableAction = visualTarget
        ? { ...action, visualTarget, expectedPageEpoch: Number(safeContext.page?.epoch || 0) }
        : action;
      let result;
      try {
        if (visualTarget && !(await visualObservationIsCurrent(tabId, visual))) {
          visualCache.delete(tabId);
          result = { status: "blocked", reason: "Visual observation is stale; the visible pixels changed after local OCR" };
        } else {
          result = await sendFrame(tabId, frameId, {
            type: visualTarget ? "PROPOSE_VISUAL_ACTION" : "PROPOSE_ACTION",
            action: executableAction
          });
        }
      } catch (error) {
        result = { status: "blocked", reason: error.message || "Target frame unavailable" };
      }
      session.history.push({ action, result });
      broadcast({ type: "ACTION_RESULT", tabId, action, result });

      if (result?.status === "needs_confirmation") {
        session.pending = { action: executableAction, frameId, visual: Boolean(visualTarget) };
        broadcast({ type: "CONFIRMATION_REQUIRED", tabId, action, result });
        return;
      }

      await new Promise((resolve) => setTimeout(resolve, action.type === "wait" ? Number(action.ms || 350) : 250));
    }
    if (sessions.has(tabId)) {
      broadcast({ type: "TASK_DONE", tabId, message: "Stopped after 10 agent steps to prevent an unbounded loop.", history: session.history });
      sessions.delete(tabId);
    }
  } catch (error) {
    broadcast({ type: "TASK_ERROR", tabId, error: error.message || String(error) });
    sessions.delete(tabId);
  } finally {
    const current = sessions.get(tabId);
    if (current) current.running = false;
  }
}

async function startTask(task) {
  if (!task) throw new Error("Enter a task before starting the agent");
  const tabId = await activeTabId();
  const settings = await getSettings();
  const taskScope = crypto.randomUUID();
  await sendAllFrames(tabId, { type: "SYNC_SETTINGS", settings });
  await sendAllFrames(tabId, { type: "SET_TASK", task, taskScope });
  const taskPrivacy = await prepareTaskPrivacy(tabId, task, settings, taskScope);
  sessions.set(tabId, {
    tabId,
    task,
    taskScope,
    safeTask: taskPrivacy.safeTask,
    taskPrivateEntities: taskPrivacy.entities.map((entity) => ({ type: entity.type, token: entity.token })),
    history: [],
    step: 0,
    pending: null,
    running: false,
    cancelled: false,
    elementFrames: new Map()
  });
  broadcast({ type: "TASK_STARTED", tabId, task });
  runSession(tabId);
  return { ok: true, tabId };
}

async function confirmPending(allow) {
  const tabId = await activeTabId();
  const session = sessions.get(tabId);
  if (!session?.pending) throw new Error("No pending high-risk action");
  const { action, frameId, visual } = session.pending;
  session.pending = null;
  let result;
  if (allow) {
    if (visual && !(await visualObservationIsCurrent(tabId, visualCache.get(tabId)))) {
      visualCache.delete(tabId);
      result = { status: "blocked", reason: "Visual confirmation expired because the visible pixels changed" };
    } else {
      result = await sendFrame(tabId, frameId, {
        type: visual ? "EXECUTE_VISUAL_CONFIRMED" : "EXECUTE_CONFIRMED",
        action
      });
    }
  } else {
    result = { status: "blocked", reason: "User blocked the action locally" };
  }
  session.history.push({ action, result, userDecision: allow ? "allow_once" : "block" });
  broadcast({ type: "ACTION_RESULT", tabId, action, result });
  session.running = false;
  if (!allow) {
    broadcast({ type: "TASK_DONE", tabId, message: "Action blocked by the user.", history: session.history });
    sessions.delete(tabId);
    return { ok: true, blocked: true };
  }
  session.step += 1;
  runSession(tabId);
  return { ok: true };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || message.source === "gateway-worker" || message.target === "offscreen") return undefined;
  if (message.source === "gateway-offscreen") {
    if (message.type === "VISUAL_OCR_PROGRESS") {
      broadcast({ type: "VISUAL_OCR_PROGRESS", status: message.status, progress: message.progress });
    }
    return undefined;
  }
  const handle = async () => {
    if (message.type === "GET_SETTINGS") return { settings: await getSettings() };
    if (message.type === "SAVE_SETTINGS") {
      const current = await getSettings();
      const settings = mergeSettings({
        ...current,
        ...message.settings,
        provider: { ...current.provider, ...(message.settings?.provider || {}) },
        userProfile: { ...current.userProfile, ...(message.settings?.userProfile || {}) }
      });
      await saveSettings(settings);
      try {
        const tabId = await activeTabId();
        await sendAllFrames(tabId, { type: "SYNC_SETTINGS", settings });
      } catch (_) {}
      return { ok: true, settings };
    }
    if (message.type === "START_TASK") return startTask(String(message.task || "").trim());
    if (message.type === "CONFIRM_PENDING") return confirmPending(Boolean(message.allow));
    if (message.type === "REFRESH_CONTEXT") {
      const tabId = await activeTabId();
      await syncSettings(tabId);
      const collected = await collectContext(tabId);
      const cached = visualCache.get(tabId);
      const visual = cached && Number(cached.epoch) === Number(collected.safeContext.page?.epoch) ? cached : null;
      const context = augmentWithVisual(collected.safeContext, visual);
      const localPreview = visual
        ? [...collected.localPreview, ...(visual.localPreview || [])].slice(0, 24)
        : collected.localPreview;
      broadcast({ type: "CONTEXT", tabId, context, localPreview });
      return { ok: true, context, localPreview, receipts: await collectAudit(tabId) };
    }
    if (message.type === "GET_AUDIT") {
      const tabId = await activeTabId();
      return { ok: true, receipts: await collectAudit(tabId) };
    }
    if (message.type === "VISUAL_SCAN") {
      const tabId = await activeTabId();
      await syncSettings(tabId);
      const collected = await collectContext(tabId);
      const visual = await captureVisualContext(tabId, collected.safeContext);
      const context = augmentWithVisual(collected.safeContext, visual);
      const localPreview = [...collected.localPreview, ...(visual.localPreview || [])].slice(0, 24);
      broadcast({ type: "CONTEXT", tabId, context, localPreview });
      return {
        ok: true,
        context,
        localPreview,
        visual: { lineCount: visual.elements.length, ocrMs: visual.ocrMs, confidence: visual.confidence }
      };
    }
    if (message.type === "STOP_TASK") {
      const tabId = await activeTabId();
      const session = sessions.get(tabId);
      if (session) session.cancelled = true;
      sessions.delete(tabId);
      broadcast({ type: "TASK_DONE", tabId, message: "Task stopped." });
      return { ok: true };
    }
    return null;
  };
  handle().then(sendResponse).catch((error) => sendResponse({ ok: false, error: error.message || String(error) }));
  return true;
});
