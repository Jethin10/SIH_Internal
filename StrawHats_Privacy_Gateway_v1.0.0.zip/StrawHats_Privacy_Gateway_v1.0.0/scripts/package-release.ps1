$ErrorActionPreference = "Stop"

$extensionRoot = Split-Path -Parent $PSScriptRoot
$releaseName = "StrawHats_Privacy_Gateway_v1.0.0"
$zipPath = Join-Path (Split-Path -Parent $extensionRoot) "$releaseName.zip"
$checksumPath = "$zipPath.sha256.txt"
$stage = Join-Path ([System.IO.Path]::GetTempPath()) ("strawhats-release-" + [guid]::NewGuid().ToString("N"))
$stageRoot = Join-Path $stage $releaseName

New-Item -ItemType Directory -Force $stageRoot | Out-Null

$files = @(
  "manifest.json",
  "README.md",
  "ARCHITECTURE-COVERAGE.md",
  "SIH-EVALUATION.md",
  "DEMO.md",
  "TEAM-RESPONSIBILITIES.md",
  "PROJECT-STATUS.md",
  "package.json",
  ".gitignore"
)
$directories = @(
  "background",
  "content",
  "lib",
  "sidepanel",
  "visual",
  "server",
  "artifacts",
  "vendor",
  "tests",
  "scripts",
  ".github"
)

foreach ($file in $files) {
  Copy-Item (Join-Path $extensionRoot $file) (Join-Path $stageRoot $file)
}
foreach ($directory in $directories) {
  Copy-Item (Join-Path $extensionRoot $directory) (Join-Path $stageRoot $directory) -Recurse
}

if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Compress-Archive -Path $stageRoot -DestinationPath $zipPath -CompressionLevel Optimal
$stream = [System.IO.File]::OpenRead($zipPath)
$sha256 = [System.Security.Cryptography.SHA256]::Create()
try {
  $hashBytes = $sha256.ComputeHash($stream)
  $hash = ([System.BitConverter]::ToString($hashBytes)).Replace("-", "")
} finally {
  $stream.Dispose()
  $sha256.Dispose()
}
Set-Content -Path $checksumPath -Value "$hash  $releaseName.zip" -Encoding ascii

Remove-Item $stage -Recurse -Force

Write-Output "Release: $zipPath"
Write-Output "SHA256: $hash"
